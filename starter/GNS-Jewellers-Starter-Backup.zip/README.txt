GNS Jewellers website backup
==============================
data/*.json   all website data: site text and headings (site_settings), categories, products, rates, enquiries, orders...
images/       every product and website photo, kept under its storage path
manifest.json what is inside and when it was made

Restore it from Admin -> Backup -> Restore. Do not edit the files by hand.
Customer enquiries and order details in this file are private: keep it somewhere safe.
